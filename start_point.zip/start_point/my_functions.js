myFunctions = {
  //write your methods here
};

module.exports = myFunctions;
